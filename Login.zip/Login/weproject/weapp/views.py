from django.shortcuts import render,redirect
from .models import therg
from django.http import JsonResponse

def first(request):
    return render(request, 'first.html')

def register(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        confirm_password = request.POST.get("cpassword")
        
        if not (username and email and password and confirm_password):
            return JsonResponse({"message": "Please fill out all required fields."}, status=400)
        
        if password != confirm_password:
            return JsonResponse({"message": "Passwords do not match."}, status=400)
        
        try:
            user = therg.objects.create(username=username, email=email, password=password)
            user.save()
            # Redirect to the login page after successful registration
            return redirect('login')  # Assuming you have a URL pattern named 'login' for your login page
        except Exception as e:
            return JsonResponse({"message": str(e)}, status=500)
    else:
        return render(request, 'register.html')

def login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        if not (username and password):
            return JsonResponse({"message": "Please provide both username and password."}, status=400)

        try:
            user = therg.objects.get(username=username, password=password)
            if user:
                # Perform login actions here if needed
                return JsonResponse({"message": "Login successful."}, status=200)
            else:
                return JsonResponse({"message": "Invalid username or password."}, status=401)
        except therg.DoesNotExist:
            return JsonResponse({"message": "Invalid username or password."}, status=401)
    else:
        return render(request, 'login.html')

def main(request):
    return render(request, 'main.html')